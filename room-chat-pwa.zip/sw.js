const CACHE = 'roomchat-v16';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon.svg', 'icons/icon-maskable-192.png', 'icons/icon-maskable-512.png',
  'https://cdn.jsdelivr.net/npm/tweetnacl@1.0.3/nacl-fast.min.js',
  'https://cdn.jsdelivr.net/npm/mqtt@5.10.1/dist/mqtt.min.js'];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET') return;
  const ours = u.origin === location.origin && !u.pathname.startsWith('/socket.io');
  const lib = u.hostname === 'cdn.jsdelivr.net';
  if (!ours && !lib) return;
  // Pages: try the network first so updates arrive, fall back to the saved copy offline. Libraries and icons: saved copy first.
  const netFirst = r.mode === 'navigate' || u.pathname.endsWith('.html') || u.pathname.endsWith('/');
  e.respondWith(netFirst
    ? fetch(r).then(x => { const y = x.clone(); caches.open(CACHE).then(c => c.put(r, y)); return x; }).catch(() => caches.match(r).then(m => m || caches.match('index.html')))
    : caches.match(r).then(m => m || fetch(r).then(x => { if (x.ok) { const y = x.clone(); caches.open(CACHE).then(c => c.put(r, y)); } return x; })));
});
// Tapping a notification brings the chat back to the front (or opens it).
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
    for (const c of list) if ('focus' in c) return c.focus();
    if (self.clients.openWindow) return self.clients.openWindow('./index.html');
  }));
});
