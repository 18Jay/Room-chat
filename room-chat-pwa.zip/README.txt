Room Chat (PWA)
1. Upload all files in this folder to your web host (your Render server) and open index.html over HTTPS.
2. On your phone: browser menu > "Install app" / "Add to Home Screen".
Files: index.html, manifest.webmanifest, sw.js, icons/

Chat list (Messenger-style)
- The app opens on a list of all your chats, with the last message, time and an unread count. Tap + to start a new chat with one person or a group; give them the chat name and password. Every chat is separate.
- Chats with a saved password are watched in the background, so previews, unread counts and alerts update even when the chat is not open. Tap the back arrow to return to the list; use the x on a row or the three-dot menu to remove a chat.

Notifications, typing and seen
- Tap "Turn on notifications" inside a room (or allow the prompt when you first join). On iPhone this only works after "Add to Home Screen" (iOS 16.4 or newer).
- You get an alert when a message or photo arrives while the app is in the background or another tab is in front.
- "Typing..." shows under the messages while someone is typing.
- Your messages show "Sent" and change to "Seen" once the other person has the chat open on screen.
- Alerts only arrive while the app is still running in the background. A fully closed app cannot be woken without a push server.

Deleting messages
- Tap the ⋯ on any message. "Delete for me" removes it from this device only. On your own messages, "Delete for everyone" also removes it for the others. It disappears completely, with no "deleted" notice left behind.
- Only the person who sent a message can delete it for everyone.

Servers
- The app connects to 5 public relays at once (EMQX, HiveMQ, Mosquitto, Eclipse, MQTTHQ); a message only has to get through one of them.
- Under "Your own servers" you can enter several of your own Render servers, separated by spaces or commas. They are all used alongside the public relays.

Look
- The interface now uses a Messenger-style look: blue accent, rounded pill inputs and buttons, gradient message bubbles, and a circular compose button on the chat list. Light and dark mode are both covered.

Video calls
- Tap the camera button next to the three-dot menu: your camera (or only your microphone) opens straight away and the call waits for the other person to join. You see yourself full screen while waiting.
- Video | Audio only switch at the top: use it while waiting or during the call. Your last choice is remembered for the next call.
- The other person sees an incoming call screen (ring tone, vibration, notification if the app is in the background) and answers with Video or Audio only. If they open the chat later, they still see the call while you are waiting.
- If the camera or microphone cannot open, the call screen stays open and shows the exact reason (for example NotAllowedError) with a "Try again" button, so you can still join without them.
- Calls are one to one and go directly between the two devices (WebRTC). Set-up messages travel through the same encrypted relays as the chat; the video itself does not.
- During a call: mute the microphone, switch Video/Audio only, switch front/back camera (phones), end the call. The screen stays awake.
- In a converted app (Android/iOS wrapper) the app itself must be given Camera and Microphone permission; the web page cannot grant this.
- Public STUN servers are used; on some strict networks or VPNs a direct call may not connect because no TURN relay is configured.

Relay status
- The "Connected (x/y relays)" status is now the first line inside the three-dot menu instead of the top bar.

HTTPS
- The page redirects itself from http:// to https:// (local addresses such as localhost and 192.168.x.x are left alone for testing), and asks the browser to upgrade any insecure sub-requests.
- If you wrap the page as an app (Capacitor, Cordova, Android WebView, PWABuilder, etc.) and it ends up on a non-secure address such as file://, it loads your hosted https copy instead. Set HOSTED near the top of index.html (e.g. 'https://my-chat.onrender.com/'), otherwise the first address saved under "Your own servers" is used.
- Point the app wrapper's start URL at your https address. Also turn on "Force HTTPS" at your host (Render does this by default).

Camera blocked (NotAllowedError, "denied")
- Browsers never give the camera or microphone to a page opened from a file (file:// or content:// - for example opened from a file manager or Downloads). Permission settings cannot change that. The app now shows a yellow notice in that case.
- Fix: upload all files to your web host and open the https address (for example your Render address). Then allow Camera and Microphone once for that address (lock icon).

